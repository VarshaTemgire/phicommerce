

const progressBar = {
  Bar: $('#progress-bar'),
  Reset: function() {
    if (this.Bar) {
      this.Bar.find('li').removeClass('active');
    }
  },
  Next: function() {
    const current = $('#progress-bar li:not(.active):first');
    current.addClass('active');
    if (current.data('month')) {
      changeInterestText(current.data('month'), current.data('roi'));
    }
  
  },
  Back: function() {
    const current = $('#progress-bar li.active:last');
    current.removeClass('active');
    const newActive = $('#progress-bar li.active:last');
    if (newActive.data('month')) {
      changeInterestText(newActive.data('month'), newActive.data('roi'));
    }
  }
}

/**
 * 
 * @param {month} Number of months
 * @param {rateOfInterest} Rate of interest for the month
 */
function changeInterestText(month, rateOfInterest) {
  $('#interest-text').html(
    `<p id="months">${month}</p>&nbsp;<p>Months @</p> &nbsp; <p id="interest-val">${rateOfInterest}</p>&nbsp; <p>interest</p>`
  );
  
}

$("#Next").on('click', () => {
  progressBar.Next();
 
});

$("#Back").on('click', () => {
  progressBar.Back();
});

$("#Reset").on('click', () => {
  progressBar.Reset();
});

  
  
  
  $(document).ready(function(){
    
    $('#progress-bar li').click(function(){
            
            $(this).addClass('active');
    
                 var dataStep = $(this).attr('data-step');
                $('#progress-bar li').each(function() {
                    if($(this).attr('data-step') > dataStep){
                        $(this).removeClass('active');
                    }else{
                        $(this).addClass('active');
                    }
                });
                
        })
          })
          
   
          
     $(document).ready(function(){
    
         $('#3-months').click(function(){
          $('#months').text("3");
            $('#interest-val').text("6.20%");
            
        })
     })   
      $(document).ready(function(){
    
         $('#6-months').click(function(){
          $('#months').text("6");
            $('#interest-val').text("6.80%");    
        })
     })   
      $(document).ready(function(){
    
         $('#12-months').click(function(){
          $('#months').text("12");
            $('#interest-val').text("7.60%");     
        })
     })   
      $(document).ready(function(){
    
         $('#18-months').click(function(){
          $('#months').text("18");
            $('#interest-val').text("8.60%");     
        })
     })   
      $(document).ready(function(){
    
         $('#24-months').click(function(){
          $('#months').text("24");
            $('#interest-val').text("10.50%");     
        })
     })  
    
    
//   otp
   
$('.digit-group').find('input').each(function() {
	$(this).attr('maxlength', 1);
	$(this).on('keyup', function(e) {
		var parent = $($(this).parent());
		
		if(e.keyCode === 8 || e.keyCode === 37) {
			var prev = parent.find('input#' + $(this).data('previous'));
			
			if(prev.length) {
				$(prev).select();
			}
		} else if((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
			var next = parent.find('input#' + $(this).data('next'));
			
			if(next.length) {
				$(next).select();
			} else {
				if(parent.data('autosubmit')) {
					parent.submit();
				}
			}
		}
	});
});
$(function () {
  $('#digit-6').keyup(function () {
      if ($(this).val() == '') {
          //Check to see if there is any text entered
          // If there is no text within the input then disable the button
          $('#verifyBtn').prop('disabled', true);
      } else {
          //If there is text in the input, then enable the button
          $('#verifyBtn').prop('disabled', false);
      }
});
});


   
//card
$(document).ready(function() {
  $("#card-accordion").click(function() {
  $("#enablebtnn").css("display","none");  
  $("#enablebtn1").css("display","none"); 
  $("#enablebtn").css("display","block");
  $("#enablebtnu").css("display","none"); 
  $('.enableOnInput').prop('disabled', true);     
  });
  });
// display img on card no
$(function () {
  $('#cardno').keyup(function () {
    if ($(this).val().length > 11) {
        $(".cardno img").css("display","block")
    }
    else  {
        $(".cardno img").css("display","none")
    }
});
});
// card number validation
$('#cardno').mask('0000 0000 0000 0000');

$(function () {
  $('#CVV,#cardno,#exp').keyup(function () {
      if ($('#CVV').val().length > 2 && $('#cardno').val().length > 18 && $('#exp').val().length > 4 ) {
          //Check to see if there is any text entered
          // If there is no text within the input then disable the button
          $('.enableOnInput').prop('disabled', false);
      } else {
          //If there is text in the input, then enable the button
          $('.enableOnInput').prop('disabled', true);
      }
  });
});
$(function () {
  $('#searchInput6').keyup(function () {
      if ($('#searchInput6').val().length > 2) {
          //Check to see if there is any text entered
          // If there is no text within the input then disable the button
          $('.enableOnInput').prop('disabled', false);
      } else {
          //If there is text in the input, then enable the button
          $('.enableOnInput').prop('disabled', true);
      }
  });
});

$(function () {
  $(document).ready(function() {
    $("#expiry,#exp").keyup(function(){
    if ($(this).val().length == 2){
    $(this).val($(this).val() + "/");
    }else if ($(this).val().length == 6){
    $(this).val($(this).val() + "/");
    }
    });
    });
 
}); 
$( document ).ready(function() {
  $( "#searchInput4,#searchInputt4,#company-name" ).keypress(function(e) {
      var key = e.keyCode;
      if (key >= 48 && key <= 57) {
          e.preventDefault();
      }
  });

});
function isNumberKey(evt) {
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
  return false;
  } else {
  return true;
  }  
  var ini=$("#searchInput").val().length; 
  if(ini<3) {
  alert("Sorry! Second decimal point not allowed.");
  }
  console.log("ini");
  }
$(document).ready(function() {
  $("#delete1").click(function() {
  $("#card-rem1").remove();      
  });
  });
  $(document).ready(function() {
  $("#delete2").click(function() {
  $("#card-rem2").remove();      
  });
  });          
  
$(document).ready(function() {
  $("input[id$='exampleRadios1'],input[id$='exampleRadios2']").click(function() {
  $("div.ifcheckedesave").show();    
  $("div.ifcheckede1").hide();  
  });
  });
  // new card option detail
$(document).ready(function() {
$("input[id$='exampleRadios3']").click(function() {
$("div.ifcheckede1").show();  
$("div.ifcheckedesave").hide();      
});
});         
//card button proceed to pay modal popup
$(document).ready(function() {
  $("#submitBtn").click(function() {
  $("#myModal2").css("display","block");
  });
  });
  // close popup
  $(document).ready(function() {
  $(".close").click(function(){
  $("#myModal2").css("display","none");
  });
  });
  $('.enableOnInput').click(function () {
    $('.js-timeout').text("3:00");
    countdown();
  }); 
  $(document).ready(function() {
    $("#verifyBtn").click(function() {
    $("#myModal3").css("display","block");
    $("#myModal2").css("display","none");
    });
    });
    // close popup
    $(document).ready(function() {
    $(".close").click(function(){
    $("#myModal3").css("display","none");
    });
    });

//emi
$(document).ready(function() {
  $("#emi-accordion").click(function() {
  $("#enablebtn1").css("display","none");  
  $("#enablebtn").css("display","none"); 
  $("#enablebtnn").css("display","block");
  $("#enablebtnu").css("display","none"); 
  $('.enableOnInputt').prop('disabled', true);     
  });
  });
  $(function () {
    $('#Back,#Next,#3-months,#6-months,#Next,#3-months,#6-months,#12-months,#18-months,#24-months').click(function () {
         
        if($("#progress-bar li").hasClass("active")){
             $('.enableOnInputt').prop('disabled', false);
        }
        else{
            $('.enableOnInputt').prop('disabled', true);
        }
});

});
// card number validation
$('#searchInputt3').mask('0000 0000 0000 0000');
// display img on card no
$(function () {
  $('#searchInputt3').keyup(function () {
    if ($(this).val().length > 11) {
        $(".cardno1 img").css("display","block")
    }
    else  {
        $(".cardno1 img").css("display","none")
    }
});
});
$(function () {
  $('#searchInputt6,#searchInputt3,#searchInputt5').keyup(function () {
      if ($('#searchInputt6').val().length > 2 && $('#searchInputt3').val().length > 18 && $('#searchInputt5').val().length > 4 && $("#progress-bar li").hasClass("active") ) {
          //Check to see if there is any text entered
          // If there is no text within the input then disable the button
          $('.enableOnInputt').prop('disabled', false);
      } else {
          //If there is text in the input, then enable the button
          $('.enableOnInputt').prop('disabled', true);
      }
  });
});
$(function () {
  $(document).ready(function() {
    $("#searchInputt5").keyup(function(){
    if ($(this).val().length == 2){
    $(this).val($(this).val() + "/");
    }else if ($(this).val().length == 6){
    $(this).val($(this).val() + "/");
    }
    });
    });
 
}); 
//netbanking
$(document).ready(function() {
  $("#net-accordion").click(function() {
  $("#enablebtn1").css("display","block");  
  $("#enablebtn").css("display","none"); 
  $("#enablebtnn").css("display","none");
  $("#enablebtnu").css("display","none"); 
  $('.enableOnInput1').prop('disabled', true);     
  });
  });
  // enable procced button on input feild fill on netbanking
$(function () {
  $('#bank1,#bank2,#bank3,#bank4,#bank5,select').click(function () {
      
      $('.enableOnInput1').prop('disabled', false);  
});
});
$(document).ready(function() {

$(".choose-bank").on("click", function () {
  $('#bank-name option').prop('selected', function() {
      return this.defaultSelected;
  });
});
});
 $(function () {
  $('#bank1').click(function () {
      
    $('#bank1').css("border","1px solid #2568B9");
    $('#bank2').css("border","0px solid #2568B9")
    $('#bank3').css("border","0px solid #2568B9")
    $('#bank4').css("border","0px solid #2568B9")
    $('#bank5').css("border","0px solid #2568B9")
});
});
$(function () {
  $('#bank2').click(function () {
      
    $('#bank2').css("border","1px solid #2568B9");
     $('#bank1').css("border","0px solid #2568B9")
    $('#bank3').css("border","0px solid #2568B9")
    $('#bank4').css("border","0px solid #2568B9")
    $('#bank5').css("border","0px solid #2568B9")
});
});
$(function () {
  $('#bank3').click(function () {
      
    $('#bank3').css("border","1px solid #2568B9")
     $('#bank2').css("border","0px solid #2568B9")
    $('#bank1').css("border","0px solid #2568B9")
    $('#bank4').css("border","0px solid #2568B9")
    $('#bank5').css("border","0px solid #2568B9")
});
});
$(function () {
  $('#bank4').click(function () {
      
    $('#bank4').css("border","1px solid #2568B9")
     $('#bank2').css("border","0px solid #2568B9")
    $('#bank3').css("border","0px solid #2568B9")
    $('#bank1').css("border","0px solid #2568B9")
    $('#bank5').css("border","0px solid #2568B9")
});
});
$(function () {
  $('#bank5').click(function () {
      
    $('#bank5').css("border","1px solid #2568B9")
     $('#bank2').css("border","0px solid #2568B9")
    $('#bank3').css("border","0px solid #2568B9")
    $('#bank4').css("border","0px solid #2568B9")
    $('#bank1').css("border","0px solid #2568B9")
});
});
$(function () {
  $('select').click(function () {
    $('#bank5').css("border","0px solid #2568B9")
    $('#bank2').css("border","0px solid #2568B9")
   $('#bank3').css("border","0px solid #2568B9")
   $('#bank4').css("border","0px solid #2568B9")
   $('#bank1').css("border","0px solid #2568B9")
});
});
//neft-rtgs
$(document).ready(function() {
  $("#wallet-accordion").click(function() {
  $("#enablebtn").css("display","none");
  $("#enablebtnu").css("display","none");
  $("#enablebtn1").css("display","none");
  $("#enablebtnn").css("display","none");
  });
  });

  //upi 
          $(function () {
            $('#upiid').keyup(function () {
                if ($('#upiid').val().length >= 8) {
                    //Check to see if there is any text entered
                    // If there is no text within the input then disable the button
                    $('#verify').prop('disabled', false);
                } else {
                    //If there is text in the input, then enable the button
                    $('#verify').prop('disabled', true);
                }
            });
          });
        
          
        // on upi click display upi option
  $(document).ready(function() {
    $("#upi-accordion,#googlepay-accordion").click(function() {
     $("#enablebtnu").css("display","block"); 
    $('.enableOnInputu').prop('disabled', true);    
    $("#enablebtn1").css("display","none");
     $("#myModal").css("display","none");
     $("#enablebtnn").css("display","none"); 
    $("#enablebtn").css("display","none"); 
    });
    });      
  // upi flow button
  $(function () {
    $('#upiid').keyup(function () {
        if ($(this).val() == '') {
            //Check to see if there is any text entered
            // If there is no text within the input then disable the button
            $('.enableOnInputu').prop('disabled', true);
        } else {
            //If there is text in the input, then enable the button
            $('.enableOnInputu').prop('disabled', false);
           
        }
    });
  }); 
    
  $(function () {
    $('#contactno').keyup(function () {
        if ($('#contactno').val().length == 10) {
            //Check to see if there is any text entered
            // If there is no text within the input then disable the button
           // If there is no text within the input then disable the button
           $('.enableOnInputu').prop('disabled', false);
          } else {
              //If there is text in the input, then enable the button
              $('.enableOnInputu').prop('disabled', true);
             
          }
    });
  });

  $(document).ready(function() {
    $(".pay-app,.enableOnInputu").click(function() {
    $("#myModalapp").css("display","block");
    // $(".footer ").css("display","none");
    // $("#enablebtn").css("display","none");
    });
    });
    // close popup
    $(document).ready(function() {
    $(".close").click(function(){
    $("#myModalapp").css("display","none");
    // $(".footer ").css("display","flex");
    // $("#enablebtn").css("display","block");
    });
    });
    $('.pay-app,.enableOnInputu ').click(function () {
      $('.js-timeout').text("3:00");
      countdown();
    }); 
    $(document).ready(function() {
      $(".refresh1").click(function() {
      location.reload(true)
      });
      });
      $(document).ready(function() {
        $(".scan-qr").click(function() {
        $("#myModal6").css("display","block");
        });
        });
        // close popup
        $(document).ready(function() {
        $(".close").click(function(){
        $("#myModal6").css("display","none");
        });
        });
        $('.scan-qr').click(function () {
          $('.js-timeout').text("0:30");
          countdown();
        });
  // bharatqr popup open
  $(document).ready(function() {
    $("#paylater-accordion").click(function() {
      $("#myModal").css("display","block");
    $("#enablebtu").css("display","block");  
    $('.enableOnInputu').prop('disabled', true);
    $("#enablebtn1").css("display","none");
     $("#enablebtnn").css("display","none"); 
    $("#enablebtn").css("display","none");        
    });
    });

    $(document).ready(function() {
      $(".close").click(function(){
      $("#myModal").css("display","none");
      });
      });

      // countdown
  var interval;

  function countdown() {
    clearInterval(interval);
    interval = setInterval( function() {
        var timer = $('.js-timeout').html();
        timer = timer.split(':');
        var minutes = timer[0];
        var seconds = timer[1];
        seconds -= 1;
        if (minutes < 0) return;
        else if (seconds < 0 && minutes != 0) {
            minutes -= 1;
            seconds = 59;
        }
        else if (seconds < 10 && length.seconds != 2) seconds = '0' + seconds;
  
        $('.js-timeout').html(minutes + ':' + seconds);
  
        if (minutes == 0 && seconds == 0) clearInterval(interval);
    }, 1000);
  }
  $('#paylater-accordion').click(function () {
    $('.js-timeout').text("3:00");
    countdown();
  }); 